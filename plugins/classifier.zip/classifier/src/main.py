from fastapi import FastAPI, UploadFile
from fastapi.responses import FileResponse
import tempfile, shutil, os
from .pdf_cluster_dit import cluster_dir

app = FastAPI()

@app.post("/classify")
async def classify(files: list[UploadFile]):
    with tempfile.TemporaryDirectory() as tmpdir:
        for f in files:
            shutil.copyfileobj(f.file, open(os.path.join(tmpdir, f.filename), "wb"))
        _, yaml_path = tempfile.mkstemp(suffix=".yaml")
        cluster_dir(tmpdir, yaml_path)
        return FileResponse(
            yaml_path, 
            media_type="text/yaml",
            filename="clusters.yaml"
        )